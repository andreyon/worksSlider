jQuery(document).ready(function () {
    /*$('.slider-container').slick({
        centerMode: true,
//центруем текущий слайд
        centerPadding: '50px',
//слегка увеличиваем текущий слайд
        slidesToShow: 3
    });*/


    $('.slider-container').slick({
        centerMode: true,
//центруем текущий слайд
        centerPadding: '50px',
//слегка увеличиваем текущий слайд
        slidesToShow: 3
    });
});
